import logo from './logo.svg';
import './App.css';
import 'antd/dist/reset.css';
import axios from "axios";
import { Table, Button } from 'antd';
import { useEffect, useState } from 'react';
import { Route,Routes,useNavigate } from 'react-router-dom';
import Employee from './Employee';
import Home from './Home';
function App() {
  const [data, setData] = useState([])
  useEffect(() => {
    fetchRecords()
  }, [])
const handleClick=(e)=>{
  console.log(e.target.value);
}
const navigate=useNavigate();
const navigateToEmployee=()=>{
  navigate('/Employee')
};
const navigateHome=()=>{
  navigate('/');
}
  const fetchRecords = () => {
    fetch("https://jsonplaceholder.typicode.com/users").then(res => {
      res.json().then((response) => {
        console.log(response)
        setData(response);
      })
    })
  }
  const columns = [{
    title: 'Id',
    dataIndex: 'id',
    key: 'key'
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'key',
    render: name => {
      return <a key={columns.Id} style={{ color: 'blue' }} onClick={handleClick}>{name}</a>
    }
  },
  {
    title: 'Username',
    dataIndex: 'username',
    key: 'key'
  }, {
    title: 'Email',
    dataIndex: 'email'
  }, 
  {
    title: 'Address',
    dataIndex: 'address.city',
    key: "Id",
  }
  ]
  return (
    <div className="App">
      <Table
        style={{ whiteSpace: 'pre' }}
        dataSource={data}
        columns={columns}
        key={columns}>
      </Table>
      <Button onClick={navigateToEmployee}>Employee</Button>
       <div onClick={handleClick}>
             {columns.name}
       </div>
       <Routes>
        <Route path="/Employee" element={<Employee/>}/>
        <Route path="/" element={<Home/>}/>
       </Routes>
    </div>
  );
}

export default App;
