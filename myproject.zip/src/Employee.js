import React from 'react'

const Employee = () => {
  return (
   <h1>
      Employee
      </h1>
  )
}

export default Employee
